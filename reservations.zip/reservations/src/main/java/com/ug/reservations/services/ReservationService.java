package com.ug.reservations.services;

import java.util.List;

import com.ug.reservations.model.Reservation;

public interface ReservationService {
	List<Reservation> seach();
}
