package com.ug.reservations.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ug.reservations.model.Reservation;
import com.ug.reservations.respositories.ReservationRepository;

@Service
public class ReservationServiceImpl implements ReservationService {
	
	@Autowired
	private ReservationRepository hotelRepository;

	@Override
	public List<Reservation> seach() {
		return (List<Reservation>) hotelRepository.findAll();
		
	}

}
