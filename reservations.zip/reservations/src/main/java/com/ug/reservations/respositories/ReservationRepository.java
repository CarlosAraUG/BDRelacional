package com.ug.reservations.respositories;

import org.springframework.data.repository.CrudRepository;

import com.ug.reservations.model.Reservation;

public interface ReservationRepository extends CrudRepository<Reservation, Integer> {

}
