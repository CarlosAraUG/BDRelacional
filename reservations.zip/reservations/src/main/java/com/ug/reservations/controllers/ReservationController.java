package com.ug.reservations.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

import com.ug.reservations.model.Reservation;
import com.ug.reservations.services.ReservationService;

@RestController
public class ReservationController {
	
	@Autowired
	private ReservationService hotelService;
	
	@GetMapping("reservations")
	public List<Reservation> search(){
		return hotelService.seach();
		
	}

}
