package com.ug.hotels.services;

import com.ug.hotels.model.Hotel;
import java.util.List;

public interface HotelService {
	List<Hotel> seach();
}