package com.ug.rooms.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ug.rooms.model.Room;
import com.ug.rooms.respositories.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {
	
	@Autowired
	private RoomRepository hotelRepository;

	@Override
	public List<Room> seach() {
		return (List<Room>) hotelRepository.findAll();
		
	}

}
