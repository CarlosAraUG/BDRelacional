package com.ug.rooms.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

import com.ug.rooms.model.Room;
import com.ug.rooms.services.RoomService;

@RestController
public class RoomController {
	
	@Autowired
	private RoomService hotelService;
	
	@GetMapping("rooms")
	public List<Room> search(){
		return hotelService.seach();
		
	}

}
