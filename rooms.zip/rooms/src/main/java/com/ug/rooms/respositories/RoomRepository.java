package com.ug.rooms.respositories;

import org.springframework.data.repository.CrudRepository;

import com.ug.rooms.model.Room;

public interface RoomRepository extends CrudRepository<Room, Integer> {

}
