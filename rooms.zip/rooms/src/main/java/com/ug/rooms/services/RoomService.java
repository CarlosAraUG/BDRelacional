package com.ug.rooms.services;

import java.util.List;

import com.ug.rooms.model.Room;

public interface RoomService {
	List<Room> seach();
}
